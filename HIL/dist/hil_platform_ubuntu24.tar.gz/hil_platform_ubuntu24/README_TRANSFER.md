# HIL 平台 Ubuntu 转移包（网站 + HIL 在 Ubuntu，主控在 Nano）

本包把 **HIL 监控/回放平台（网站）** 搬到 Ubuntu 运行。拓扑：
**Ubuntu = CARLA + 网站后端(FastAPI) + 前端(React)**，**双 Jetson Nano = 主控 ADAS.py + 网关**。

## 目录结构（务必保持不动，相对路径靠它解析）

```text
hil_platform_ubuntu24/
└── HIL/
    ├── hil_platform/          ← 网站（后端 server/ + 前端 web/ + core/ + configs/）
    │   ├── start_web_hil_ubuntu.sh      ← 一键启动（后端+前端）
    │   ├── start_real_backend_ubuntu.sh ← 仅后端
    │   └── README_Ubuntu.md             ← 详细说明（先读它）
    └── carla_bridge/
        ├── pc/               ← carla_link（CARLA 世界驱动，后端真实模式依赖）
        └── nano/             ← 网关源码（网站一键准备 HIL 时 SFTP 到 Nano）
```

> ⚠️ `hil_platform/core/carla_world.py` 与 `hardware_control.py` 用 `parents[N]` 相对定位
> `carla_bridge/`，所以 **解包后保持 `HIL/hil_platform` 与 `HIL/carla_bridge` 同级**，别拆散。

## 三步跑起来

```bash
tar -xzf hil_platform_ubuntu24.tar.gz
cd hil_platform_ubuntu24/HIL/hil_platform

# 1) 装依赖（首次）
python3 -m pip install -r requirements.txt
# 真实模式还需把 CARLA whl 装进同一个 python3（mock 模式不需要）：
#   pip install <CARLA>/PythonAPI/carla/dist/carla-0.9.16-*-linux_x86_64.whl

# 2) mock 模式先验证网站本身（无需硬件/CARLA）
HIL_MOCK=1 python3 -m server.api_server          # 后端
npm --prefix web install && npm --prefix web run dev   # 前端 → http://127.0.0.1:5173/live

# 3) 真实模式：先单独起 CARLA，再一键启动
/path/to/CARLA/CarlaUE4.sh -quality-level=Low
chmod +x start_web_hil_ubuntu.sh start_real_backend_ubuntu.sh
GATEWAY_HOST=192.168.3.125 BACKUP_HOST=192.168.3.124 PC_HOST=192.168.3.8 \
  ./start_web_hil_ubuntu.sh
```

详见 `HIL/hil_platform/README_Ubuntu.md`（依赖、环境变量表、排错）。

## 一处要注意：ADAS 代码部署不在本包内

网站「一键准备 HIL」会做两件上传：
- **网关** ← 本包 `HIL/carla_bridge/nano/`（已含，正常工作）；
- **ADAS 控制代码** ← 仓库 `仿真/soc_code/`（**本包未含，该目录不在当前发布范围**）。

因此：
- 若两台 Nano **已部署好 ADAS.py**（常态——平时用 paramiko 直接滚动部署），
  调一键准备时**关掉 deploy** 即可跳过这步：
  `POST /api/hardware/hil/prepare` body `{"deploy": false}`（或前端勾掉"部署"选项），
  网站只起网关 + 重启 Nano 上已有的 ADAS。
- 若要让网站也负责推 ADAS 代码，把 `仿真/soc_code/` 一并放到
  `hil_platform_ubuntu24/仿真/soc_code/` 再开 deploy。

## 与另一条桥的区别

`HIL/carla_bridge/pc/carla_ros_node.py` 是**另一条**桥（无网关、CARLA 直发 ROS2 话题、
**不带网站**），打包在 `hil_carla_ros2_ubuntu24.tar.gz`。**本包**走的是
**网站 + 网关**路径（`NanoLink` → TCP 42110 → `hil_ros_gateway.py` → ROS2 → ADAS.py），
即 2026-06-24 已实机验证过的 HIL 闭环。
